def generate_response(message):
    if "fever" in message.lower():
        return "You might be experiencing symptoms of viral fever. Please stay hydrated and consult a doctor."
    elif "headache" in message.lower():
        return "Try resting and drinking water. If it persists, seek medical help."
    else:
        return "I'm not sure about that. Please consult a certified medical professional."
